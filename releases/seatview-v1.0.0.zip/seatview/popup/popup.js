const SUPPORTED = /^https?:\/\/([^/]*\.)?(district\.in|bookmyshow\.com)\//i;
const FILES = ['content/geometry.js', 'content/detector.js', 'content/overlay.js', 'content/main.js'];

function showHelp(text) {
  document.getElementById('msg').textContent = text;
  document.getElementById('help').hidden = false;
}

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !SUPPORTED.test(tab.url || '')) return showHelp('This page isn\'t a supported booking site.');
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'seatview:toggle' });
    window.close();
  } catch (_) {
    // Tab was open before the extension was installed – inject the scripts now
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: FILES });
      await chrome.tabs.sendMessage(tab.id, { type: 'seatview:toggle' });
      window.close();
    } catch (e) {
      showHelp('Could not start on this page. Reload the page and try again.');
    }
  }
})();

document.getElementById('demo').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('demo/demo.html') });
document.getElementById('opts').onclick = (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); };
