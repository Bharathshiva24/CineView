// SeatView background service worker
// - Finds a trailer on YouTube for a movie title (no API key needed; optional Data API key in Options)
// - Relays the keyboard shortcut to the active tab

const CACHE_TTL_MS = 3 * 24 * 60 * 60 * 1000; // 3 days

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'seatview:searchTrailers') {
    searchTrailers(msg.query)
      .then((results) => sendResponse({ ok: true, results }))
      .catch((err) => sendResponse({ ok: false, error: String(err && err.message || err) }));
    return true; // async
  }
  return false;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-preview') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && tab.id != null) {
    chrome.tabs.sendMessage(tab.id, { type: 'seatview:toggle' }).catch(() => {});
  }
});

async function searchTrailers(rawQuery) {
  const title = (rawQuery || '').trim();
  if (!title) return [];
  const query = /trailer/i.test(title) ? title : `${title} official trailer`;
  const cacheKey = 'yt:' + query.toLowerCase();

  const cached = (await chrome.storage.local.get(cacheKey))[cacheKey];
  if (cached && Date.now() - cached.t < CACHE_TTL_MS && cached.results.length) return cached.results;

  const { apiKey } = await chrome.storage.sync.get({ apiKey: '' });
  let results = [];
  if (apiKey) {
    try { results = await searchWithDataApi(query, apiKey); } catch (e) { console.warn('[SeatView] Data API failed, falling back', e); }
  }
  if (!results.length) results = await searchWithResultsPage(query);

  results = rankTrailers(results, title).slice(0, 6);
  if (results.length) await chrome.storage.local.set({ [cacheKey]: { t: Date.now(), results } });
  return results;
}

// --- Strategy 1: official YouTube Data API v3 (only if the user saved a key) ---
async function searchWithDataApi(query, key) {
  const url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoEmbeddable=true&maxResults=10'
    + '&q=' + encodeURIComponent(query) + '&key=' + encodeURIComponent(key);
  const res = await fetch(url);
  if (!res.ok) throw new Error('YouTube API ' + res.status);
  const data = await res.json();
  return (data.items || []).map((it) => ({
    videoId: it.id.videoId,
    title: decodeEntities(it.snippet.title),
    channel: it.snippet.channelTitle,
    length: ''
  }));
}

// --- Strategy 2: parse the public search results page (works without any key) ---
async function searchWithResultsPage(query) {
  // sp=EgIQAQ%3D%3D -> "Videos only" filter
  const url = 'https://www.youtube.com/results?hl=en&gl=IN&sp=EgIQAQ%253D%253D&search_query=' + encodeURIComponent(query);
  const res = await fetch(url, { credentials: 'omit' });
  if (!res.ok) throw new Error('YouTube search ' + res.status);
  const html = await res.text();

  const data = extractInitialData(html);
  const out = [];
  if (data) {
    walk(data, (node) => {
      const vr = node.videoRenderer;
      if (vr && vr.videoId) {
        out.push({
          videoId: vr.videoId,
          title: runsText(vr.title),
          channel: runsText(vr.ownerText) || runsText(vr.longBylineText),
          length: (vr.lengthText && vr.lengthText.simpleText) || ''
        });
      }
    });
  }
  if (!out.length) {
    // Last-resort regex if YouTube changes its JSON shape
    const seen = new Set();
    for (const m of html.matchAll(/"videoId":"([\w-]{11})"/g)) {
      if (!seen.has(m[1])) { seen.add(m[1]); out.push({ videoId: m[1], title: '', channel: '', length: '' }); }
      if (seen.size >= 10) break;
    }
  }
  return out;
}

function extractInitialData(html) {
  const markers = ['var ytInitialData = ', 'window["ytInitialData"] = ', 'ytInitialData = '];
  for (const marker of markers) {
    const start = html.indexOf(marker);
    if (start === -1) continue;
    const jsonStart = start + marker.length;
    const end = findJsonEnd(html, jsonStart);
    if (end > jsonStart) {
      try { return JSON.parse(html.slice(jsonStart, end)); } catch (_) { /* try next */ }
    }
  }
  return null;
}

// Find the end of a JSON object starting at `i` by bracket matching (string-aware)
function findJsonEnd(s, i) {
  let depth = 0, inStr = false, esc = false;
  for (let k = i; k < s.length; k++) {
    const c = s[k];
    if (inStr) {
      if (esc) esc = false; else if (c === '\\') esc = true; else if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') inStr = true;
    else if (c === '{') depth++;
    else if (c === '}') { depth--; if (depth === 0) return k + 1; }
  }
  return -1;
}

function walk(node, fn, depth = 0) {
  if (!node || typeof node !== 'object' || depth > 40) return;
  fn(node);
  if (Array.isArray(node)) { for (const n of node) walk(n, fn, depth + 1); }
  else { for (const k in node) walk(node[k], fn, depth + 1); }
}

function runsText(t) {
  if (!t) return '';
  if (t.simpleText) return t.simpleText;
  if (Array.isArray(t.runs)) return t.runs.map((r) => r.text).join('');
  return '';
}

function durationSeconds(len) {
  if (!len) return null;
  const parts = len.split(':').map(Number);
  if (parts.some(isNaN)) return null;
  return parts.reduce((acc, p) => acc * 60 + p, 0);
}

function rankTrailers(list, movieTitle) {
  const titleWords = movieTitle.toLowerCase().split(/\s+/).filter((w) => w.length > 1);
  const seen = new Set();
  return list
    .filter((v) => v.videoId && !seen.has(v.videoId) && seen.add(v.videoId))
    .map((v, idx) => {
      const t = (v.title || '').toLowerCase();
      let score = -idx * 0.4; // keep YouTube's relevance order as a tiebreaker
      if (/trailer/.test(t)) score += 6;
      if (/official/.test(t)) score += 2;
      if (/teaser/.test(t)) score += 2;
      if (/(reaction|review|explained|breakdown|fan.?made|concept|spoof|parody|recap|ending|scene|songs?|lyric|jukebox|interview|making|bts|full movie)/.test(t)) score -= 8;
      score += titleWords.filter((w) => t.includes(w)).length * 1.5;
      const secs = durationSeconds(v.length);
      if (secs != null) { if (secs <= 240) score += 2; else if (secs > 600) score -= 6; }
      return { ...v, score };
    })
    .sort((a, b) => b.score - a.score);
}

function decodeEntities(s) {
  return String(s || '')
    .replace(/&amp;/g, '&').replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>');
}
