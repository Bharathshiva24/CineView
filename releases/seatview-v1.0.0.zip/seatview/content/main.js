// SeatView – content-script entry: tracks seat clicks, reads the movie title, opens the preview
(function () {
  const SV = (window.SeatView = window.SeatView || {});
  if (SV.__mainLoaded) return;
  SV.__mainLoaded = true;

  const LANGS = ['Hindi', 'Tamil', 'Telugu', 'Malayalam', 'Kannada', 'English', 'Bengali', 'Marathi', 'Punjabi', 'Gujarati'];
  const JUNK_RE = /^(district|bookmyshow|book ?my ?show|movies?|cinemas?|select seats?|seat layout|home|sign ?in|login|profile|back|\d+ tickets?)$/i;

  // ---- remember seat clicks (helps confirm which seats the user selected) ----
  document.addEventListener('click', (e) => {
    const t = e.target;
    if (!(t instanceof Element) || t.closest('#seatview-root')) return;
    SV.clickedSeatEls.add(t);
    if (SV.clickedSeatEls.size > 60) SV.clickedSeatEls.delete(SV.clickedSeatEls.values().next().value);
  }, true);

  // ---- movie title ----
  function cleanTitle(t) {
    if (!t) return '';
    let s = t.replace(/\s+/g, ' ').trim();
    s = s.split(/\s[|–—]\s|\s-\s(?=(book|buy|movie|district|bookmyshow|seat))/i)[0];
    s = s.replace(/\b(book|buy)\s+(movie\s+)?tickets?\b.*$/i, '')
      .replace(/\b(movie\s+tickets?|seat\s+layout|select\s+seats?|online)\b/gi, '')
      .replace(/\((u|ua|u\/a|a|s|ua\d+\+?)\)/gi, '')
      .replace(/\b(2d|3d|4dx|imax|mx4d|screenx|ice|dolby\s+atmos|dolby\s+cinema)\b/gi, '')
      .replace(/\s{2,}/g, ' ').replace(/[\s,:\-|]+$/, '').trim();
    return JUNK_RE.test(s) ? '' : s;
  }

  // Biggest bold-ish text near the top of the page (the booking header usually shows the movie name)
  function headerTitle() {
    const els = document.querySelectorAll('h1,h2,h3,header *,[class*="title" i],[class*="name" i]');
    let best = null;
    for (const el of els) {
      if (el.closest('#seatview-root')) continue;
      if ([...el.children].some((c) => (c.textContent || '').trim())) continue; // leaf text only
      const text = (el.textContent || '').trim();
      if (text.length < 1 || text.length > 70) continue;
      const r = el.getBoundingClientRect();
      if (!r.width || r.top < 0 || r.top > 260) continue;
      const cs = getComputedStyle(el);
      const size = parseFloat(cs.fontSize) || 0;
      const weight = parseInt(cs.fontWeight, 10) || 400;
      if (size < 15) continue;
      const cleaned = cleanTitle(text);
      if (!cleaned || /\d{1,2}:\d{2}|\b(am|pm)\b|₹|tickets?/i.test(text)) continue;
      const score = size + (weight >= 600 ? 4 : 0) - r.top / 60;
      if (!best || score > best.score) best = { text: cleaned, score, el };
    }
    return best;
  }

  function detectLanguage(nearEl) {
    const scope = (nearEl && nearEl.parentElement && nearEl.parentElement.parentElement) || document.body;
    const text = (scope.innerText || '').slice(0, 2000);
    return LANGS.find((l) => new RegExp('\\b' + l + '\\b', 'i').test(text)) || '';
  }

  async function rememberedTitle() {
    try {
      const { lastMovie } = await chrome.storage.local.get('lastMovie');
      if (lastMovie && Date.now() - lastMovie.t < 6 * 3600 * 1000) return lastMovie;
    } catch (_) {}
    return null;
  }

  async function getMovieTitle() {
    const head = headerTitle();
    const meta = document.querySelector('meta[property="og:title"]');
    const fromMeta = cleanTitle(meta && meta.content);
    const fromDoc = cleanTitle(document.title);
    const remembered = await rememberedTitle();

    let title = (head && head.text) || fromMeta || fromDoc;
    // Prefer the cleaner name saved from the movie's own page when it matches what this page shows
    if (remembered && (!title || document.body.innerText.toLowerCase().includes(remembered.title.toLowerCase()))) title = remembered.title;
    const lang = detectLanguage(head && head.el);
    return { title, lang };
  }

  // On a movie details page, remember the title so the seat page can use it
  function rememberMovieOnDetailsPage() {
    const path = location.pathname;
    if (/seat|buytickets|booking/i.test(path) || !/\/movies?\//i.test(path)) return;
    const h1 = document.querySelector('h1');
    const t = cleanTitle(h1 && h1.textContent);
    if (t) chrome.storage.local.set({ lastMovie: { title: t, t: Date.now(), url: location.href } }).catch(() => {});
  }

  // ---- open / close ----
  async function openPreview() {
    if (SV.Overlay.isOpen()) { SV.Overlay.close(); return; }
    let layout = SV.detectLayout();
    let message = '';
    if (!layout) {
      layout = SV.syntheticLayout();
      message = "Couldn't read a seat map on this page – showing a typical hall. Click a seat on the map that matches yours.";
    }
    const selected = layout.seats.filter((s) => s.status === 'selected')
      .sort((a, b) => a.row - b.row || a.cx - b.cx);
    let seat = selected[0];
    if (!seat) {
      seat = SV.suggestSeat(layout);
      if (!message) message = 'No selected seat found – showing a recommended seat. Pick seats on the page, or click any seat on the map.';
    }

    let settings = {};
    try { settings = (await chrome.storage.sync.get({ settings: {} })).settings || {}; } catch (_) {}
    if (/imax/i.test(document.body.innerText.slice(0, 3000)) && !settings.aspect) settings.aspect = 1.9;

    const { title, lang } = await getMovieTitle();
    const query = title && lang && !title.toLowerCase().includes(lang.toLowerCase()) ? `${title} ${lang}` : title;

    SV.Overlay.open({ layout, selected, seat, title: query, settings, message });
  }
  SV.openPreview = openPreview;

  try {
    chrome.runtime.onMessage.addListener((msg, _s, send) => {
      if (msg && msg.type === 'seatview:toggle') { openPreview(); send({ ok: true }); }
      if (msg && msg.type === 'seatview:ping') send({ ok: true });
    });
  } catch (_) { /* demo page outside an extension */ }

  rememberMovieOnDetailsPage();
  // SPA navigations
  let lastPath = location.pathname;
  setInterval(() => { if (location.pathname !== lastPath) { lastPath = location.pathname; setTimeout(rememberMovieOnDetailsPage, 1500); } }, 1000);
})();
