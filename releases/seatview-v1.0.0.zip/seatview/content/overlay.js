// SeatView – the in-page preview: a CSS-3D theatre seen from the chosen seat, with the trailer on screen
(function () {
  const SV = (window.SeatView = window.SeatView || {});
  const PX = 100; // CSS pixels per metre in the 3D world
  const RAD = Math.PI / 180;

  const CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  .backdrop { position: fixed; inset: 0; z-index: 2147483646; background: rgba(4,3,10,.82); backdrop-filter: blur(6px);
    display: flex; align-items: stretch; justify-content: center; padding: 18px;
    font: 13px/1.45 ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; color: #ece9ff;
    animation: fade .25s ease; }
  @keyframes fade { from { opacity: 0 } to { opacity: 1 } }
  .shell { display: flex; gap: 14px; width: 100%; max-width: 1680px; min-height: 0; }
  .main { flex: 1; display: flex; flex-direction: column; min-width: 0; gap: 10px; }
  .stage { position: relative; flex: 1; min-height: 320px; border-radius: 16px; overflow: hidden;
    background: radial-gradient(120% 90% at 50% 20%, #17142a 0%, #07060d 70%); perspective-origin: 50% 50%;
    box-shadow: 0 30px 80px rgba(0,0,0,.6), inset 0 0 0 1px rgba(255,255,255,.06); }
  .camera, .group { position: absolute; inset: 0; transform-style: preserve-3d; transform-origin: 50% 50%; }
  .camera { transition: transform .9s cubic-bezier(.2,.8,.2,1); }
  .camera.instant { transition: none; }
  .p { position: absolute; left: 50%; top: 50%; backface-visibility: visible; transform-origin: 50% 50%; }
  .screen { background: #000; overflow: hidden; border-radius: 2px;
    box-shadow: 0 0 140px 30px rgba(120,140,255,.18), 0 0 0 6px #050507; }
  .screen iframe { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; display: block; pointer-events: none; }
  .placeholder { container-type: size; position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6%;
    background: linear-gradient(135deg, #251a5c, #0d0b20 55%, #3a1430); color: #fff; text-align: center; padding: 4%; }
  .placeholder h2 { margin: 0; font-size: min(11cqw, 30cqh); letter-spacing: -.02em; line-height: .95; font-weight: 800; }
  .placeholder p { margin: 0; font-size: min(3.6cqw, 10cqh); opacity: .7; }
  .placeholder a { color: #ffd166; font-size: min(3cqw, 8cqh); pointer-events: auto; }
  .grid { position: absolute; inset: 0; background:
    linear-gradient(#fff 0 0) center/6px 100% no-repeat, linear-gradient(#fff 0 0) center/100% 6px no-repeat,
    repeating-linear-gradient(90deg, rgba(255,255,255,.35) 0 3px, transparent 3px 10%),
    repeating-linear-gradient(0deg, rgba(255,255,255,.35) 0 3px, transparent 3px 20%), #1a1a1a; }
  .grid::after { content: ""; position: absolute; left: 50%; top: 50%; width: 40%; aspect-ratio: 1; transform: translate(-50%,-50%);
    border: 10px solid #fff; border-radius: 50%; }
  .frontwall { background: radial-gradient(60% 55% at 50% 45%, #1d1830 0%, #0b0a12 70%), #0b0a12; }
  .curtain { background: repeating-linear-gradient(90deg, #2a0d18 0 40px, #3b1322 40px 70px, #24091a 70px 110px); opacity: .9; }
  .wall { background: linear-gradient(90deg, #0e0c18, #15121f 40%, #0c0b14),
    repeating-linear-gradient(0deg, transparent 0 140px, rgba(255,255,255,.025) 140px 142px); }
  .sconce { background: radial-gradient(closest-side, rgba(255,190,120,.55), rgba(255,170,90,.08) 60%, transparent); border-radius: 50%; }
  .exit { background: #0d7a3a; box-shadow: 0 0 30px 8px rgba(30,200,110,.35); border-radius: 4px; }
  .ceiling { background: radial-gradient(50% 60% at 50% 0%, #120f1c, #060509); }
  .floor { background: #0a090f; }
  .tread { background: linear-gradient(#141220, #0c0b12); }
  .riser { background: #08070c; }
  .riser.lit { box-shadow: inset 0 3px 0 rgba(255,200,120,.25); }
  .seatback { background: linear-gradient(#3a2230, #22121c 60%, #160b12); border-radius: 18px 18px 4px 4px;
    box-shadow: inset 0 6px 0 rgba(255,255,255,.05); }
  .head { background: radial-gradient(60% 60% at 45% 35%, #1d1a22, #050407); border-radius: 48% 48% 42% 42%; }
  .shoulders { background: #060508; border-radius: 40% 40% 0 0; }
  .vignette { position: absolute; inset: 0; pointer-events: none;
    background: radial-gradient(120% 100% at 50% 45%, transparent 55%, rgba(0,0,0,.55)); }
  .hud { position: absolute; left: 14px; top: 12px; right: 14px; display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; pointer-events: none; }
  .pill { background: rgba(10,8,22,.72); border: 1px solid rgba(255,255,255,.1); padding: 6px 11px; border-radius: 999px; font-weight: 600;
    backdrop-filter: blur(6px); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 60%; }
  .pill small { font-weight: 500; opacity: .65; margin-left: 6px; }
  .banner { position: absolute; left: 50%; bottom: 14px; transform: translateX(-50%); background: rgba(255,209,102,.95); color: #1d1600;
    padding: 7px 14px; border-radius: 10px; font-weight: 600; max-width: 80%; text-align: center; pointer-events: none; }
  .banner:empty { display: none; }
  .controls { display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
  button, select, input { font: inherit; color: inherit; }
  .btn { background: #1b1830; border: 1px solid rgba(255,255,255,.1); border-radius: 10px; padding: 7px 12px; cursor: pointer; }
  .btn:hover { background: #262141; }
  .btn.primary { background: #7c5cff; border-color: #7c5cff; color: #fff; }
  .btn.primary:hover { background: #8d71ff; }
  select.btn { max-width: 380px; }
  .spacer { flex: 1; }
  a.btn { text-decoration: none; }
  aside { width: 350px; flex: none; background: #0f0d1c; border-radius: 16px; padding: 14px; overflow: auto;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.06); display: flex; flex-direction: column; gap: 14px; }
  .head-row { display: flex; align-items: center; gap: 8px; }
  .brand { font-weight: 800; letter-spacing: .3px; font-size: 15px; }
  .brand span { color: #7c5cff; }
  .close { margin-left: auto; width: 32px; height: 32px; border-radius: 50%; padding: 0; font-size: 18px; line-height: 1; }
  label.lbl { display: block; font-size: 11px; text-transform: uppercase; letter-spacing: .8px; opacity: .55; margin-bottom: 5px; }
  .search { display: flex; gap: 6px; }
  .search input { flex: 1; min-width: 0; background: #1b1830; border: 1px solid rgba(255,255,255,.12); border-radius: 10px; padding: 7px 10px; outline: none; }
  .search input:focus { border-color: #7c5cff; }
  .chips { display: flex; gap: 6px; flex-wrap: wrap; }
  .chip { padding: 5px 10px; border-radius: 999px; background: #1b1830; border: 1px solid rgba(255,255,255,.1); cursor: pointer; font-weight: 600; }
  .chip.on { background: #ffc850; color: #241a00; border-color: #ffc850; }
  .score { display: flex; gap: 14px; align-items: center; background: #15122a; border-radius: 14px; padding: 12px; }
  .ring { position: relative; width: 74px; height: 74px; flex: none; }
  .ring svg { transform: rotate(-90deg); }
  .ring b { position: absolute; inset: 0; display: grid; place-items: center; font-size: 22px; }
  .verdict { font-weight: 700; font-size: 16px; }
  .sub { opacity: .7; font-size: 12px; }
  .metrics { display: grid; gap: 9px; }
  .metric { display: grid; grid-template-columns: 1fr auto; gap: 2px 8px; }
  .metric .v { font-weight: 700; font-variant-numeric: tabular-nums; }
  .bar { grid-column: 1 / -1; height: 5px; border-radius: 3px; background: #241f3d; position: relative; overflow: hidden; }
  .bar i { position: absolute; top: 0; bottom: 0; border-radius: 3px; }
  .bar .zone { background: rgba(73,214,140,.35); }
  .bar .mark { width: 3px; background: #fff; }
  .notes { margin: 0; padding-left: 16px; display: grid; gap: 4px; opacity: .85; }
  .map { position: relative; background: #0a0914; border-radius: 12px; overflow: hidden; }
  .map .s { position: absolute; border-radius: 3px; cursor: pointer; border: 1px solid rgba(255,255,255,.35); }
  .map .s.occupied { border-color: transparent; background: rgba(255,255,255,.12); cursor: pointer; }
  .map .s.selected { background: #7c5cff; border-color: #7c5cff; }
  .map .s.current { background: #ffc850; border-color: #fff; box-shadow: 0 0 0 2px rgba(255,200,80,.5); z-index: 2; }
  .map .s:hover { border-color: #ffc850; }
  .map .scr { position: absolute; left: 12%; right: 12%; height: 4px; border-radius: 4px; background: linear-gradient(90deg, transparent, #9d86ff, transparent); }
  .map .scrl { position: absolute; left: 0; right: 0; text-align: center; font-size: 9px; letter-spacing: 3px; opacity: .55; }
  details { background: #15122a; border-radius: 12px; padding: 10px 12px; }
  summary { cursor: pointer; font-weight: 600; }
  .set { display: grid; grid-template-columns: 1fr 64px; gap: 4px 10px; align-items: center; margin-top: 10px; }
  .set input[type=range] { grid-column: 1 / -1; width: 100%; accent-color: #7c5cff; }
  .set .val { text-align: right; opacity: .8; font-variant-numeric: tabular-nums; }
  .set select { grid-column: 1 / -1; background: #1b1830; border: 1px solid rgba(255,255,255,.12); border-radius: 8px; padding: 5px; }
  .hint { font-size: 11px; opacity: .5; }
  @media (max-width: 960px) { .shell { flex-direction: column; } aside { width: auto; max-height: 45vh; } }
  `;

  const state = {
    host: null, root: null, els: {}, layout: null, seat: null, selected: [], settings: null,
    trailers: [], trailerIdx: 0, muted: true, playing: true, title: '', view: null, onClose: null
  };

  const h = (tag, cls, html) => { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function build() {
    const host = document.createElement('div');
    host.id = 'seatview-root';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>${CSS}</style>
    <div class="backdrop">
      <div class="shell">
        <div class="main">
          <div class="stage">
            <div class="camera">
              <div class="group env"></div>
              <div class="group rows"></div>
              <div class="p screen"></div>
            </div>
            <div class="vignette"></div>
            <div class="hud"><div class="pill seatpill"></div><div class="pill moviepill"></div></div>
            <div class="banner"></div>
          </div>
          <div class="controls">
            <button class="btn primary play" title="Play / pause (Space)">❚❚ Pause</button>
            <button class="btn mute" title="Mute / unmute (M)">🔇 Unmute</button>
            <select class="btn trailers" title="Choose another video"></select>
            <button class="btn next" title="Try the next result">Next ›</button>
            <span class="spacer"></span>
            <a class="btn ytlink" target="_blank" rel="noopener">Open on YouTube ↗</a>
          </div>
        </div>
        <aside>
          <div class="head-row"><div class="brand">Seat<span>View</span></div><span class="sub">preview from your seat</span>
            <button class="btn close" title="Close (Esc)">×</button></div>
          <div><label class="lbl">Movie</label>
            <form class="search"><input class="title" placeholder="Movie title" spellcheck="false"><button class="btn primary" type="submit">Find trailer</button></form></div>
          <div class="chipwrap"><label class="lbl">Your selected seats</label><div class="chips"></div></div>
          <div class="score">
            <div class="ring"><svg width="74" height="74"><circle cx="37" cy="37" r="31" fill="none" stroke="#241f3d" stroke-width="7"/>
              <circle class="arc" cx="37" cy="37" r="31" fill="none" stroke-width="7" stroke-linecap="round" stroke-dasharray="0 999"/></svg><b class="num">–</b></div>
            <div><div class="verdict"></div><div class="sub seatline"></div></div>
          </div>
          <div class="metrics"></div>
          <ul class="notes"></ul>
          <div><label class="lbl">Seat map – click any seat to compare</label><div class="map"></div>
            <div class="hint">Arrow keys move between seats · Space play/pause · M mute · Esc close</div></div>
          <details><summary>Theatre settings</summary><div class="settings"></div>
            <div class="hint" style="margin-top:8px">Seat maps don't include real dimensions, so SeatView estimates them. Adjust if you know the hall (e.g. recliners → row spacing 1.6 m, IMAX → aspect 1.9).</div></details>
        </aside>
      </div>
    </div>`;
    const q = (s) => root.querySelector(s);
    state.els = {
      stage: q('.stage'), camera: q('.camera'), env: q('.env'), rows: q('.rows'), screen: q('.screen'),
      seatpill: q('.seatpill'), moviepill: q('.moviepill'), banner: q('.banner'), play: q('.play'), mute: q('.mute'),
      select: q('.trailers'), next: q('.next'), yt: q('.ytlink'), close: q('.close'), form: q('.search'), title: q('.title'),
      chips: q('.chips'), chipwrap: q('.chipwrap'), arc: q('.arc'), num: q('.num'), verdict: q('.verdict'), seatline: q('.seatline'),
      metrics: q('.metrics'), notes: q('.notes'), map: q('.map'), settings: q('.settings')
    };
    state.host = host; state.root = root;

    const E = state.els;
    E.close.onclick = () => SV.Overlay.close();
    root.querySelector('.backdrop').addEventListener('mousedown', (e) => { if (e.target.classList.contains('backdrop')) SV.Overlay.close(); });
    E.play.onclick = togglePlay;
    E.mute.onclick = toggleMute;
    E.next.onclick = () => playTrailer(state.trailerIdx + 1);
    E.select.onchange = () => playTrailer(Number(E.select.value));
    E.form.onsubmit = (e) => { e.preventDefault(); loadTrailers(E.title.value); };

    // Keep the page from reacting to our keystrokes
    for (const t of ['keydown', 'keyup', 'keypress']) host.addEventListener(t, (e) => e.stopPropagation());
    new ResizeObserver(() => render(true)).observe(E.stage);
    return host;
  }

  // ---------- 3D placement helpers ----------
  // Place a flat plane of w×h metres with its centre at (x, y, z) metres. y is up, z is distance from screen.
  function place(el, w, hgt, x, y, z, extra = '') {
    el.style.width = w * PX + 'px';
    el.style.height = hgt * PX + 'px';
    el.style.marginLeft = (-w * PX) / 2 + 'px';
    el.style.marginTop = (-hgt * PX) / 2 + 'px';
    el.style.transform = `translate3d(${x * PX}px, ${-y * PX}px, ${z * PX}px) ${extra}`;
    return el;
  }
  function plane(parent, cls, w, hgt, x, y, z, extra) { return parent.appendChild(place(h('div', 'p ' + cls), w, hgt, x, y, z, extra)); }

  function cameraTransform(view, stageW) {
    const s = state.settings;
    const P = stageW / 2 / Math.tan((s.fov * RAD) / 2);
    const { cam, screen } = view;
    // vector from eye to the screen centre, in CSS coordinates (y down, z towards viewer)
    const dx = 0 - cam.x, dy = -(screen.centerY - cam.y), dz = 0 - cam.z;
    const yaw = Math.atan2(dx, -dz);
    const dz2 = -dx * Math.sin(yaw) + dz * Math.cos(yaw);
    const pitch = Math.atan2(-dy, -dz2);
    return {
      P, yaw, pitch,
      css: `translateZ(${P}px) rotateX(${pitch}rad) rotateY(${yaw}rad) translate3d(${-cam.x * PX}px, ${cam.y * PX}px, ${-cam.z * PX}px)`
    };
  }

  // ---------- Scene ----------
  function render(instant) {
    if (!state.host || !state.seat) return;
    const E = state.els, s = state.settings, layout = state.layout;
    const view = SV.computeView(state.seat, layout, s);
    state.view = view;
    const stageW = E.stage.clientWidth || 1000;
    const camT = cameraTransform(view, stageW);
    E.stage.style.perspective = camT.P + 'px';
    E.camera.classList.toggle('instant', !!instant);
    E.camera.style.transform = camT.css;

    const { cam, screen, hall } = view;
    const halfFov = (s.fov / 2 + 12) * RAD;
    const pitchUp = Math.max(0, camT.pitch);
    // visible horizontal angle range (measured from straight-at-screen axis, +x to the right)
    const lookAngle = Math.atan2(-cam.x, cam.z);
    const angLo = Math.max(-85 * RAD, lookAngle - halfFov), angHi = Math.min(85 * RAD, lookAngle + halfFov);
    const xRangeAt = (dzAhead) => [cam.x + dzAhead * Math.tan(angLo), cam.x + dzAhead * Math.tan(angHi)];
    const maxDepress = (80 * RAD) - pitchUp; // keep geometry in front of the eye

    // Screen (persistent element so the video keeps playing)
    place(E.screen, screen.w, screen.h, 0, screen.centerY, 0);

    // Environment
    const env = E.env; env.textContent = '';
    const H = Math.max(screen.bottom + screen.h + 2.5, 8);
    const backZ = cam.z;
    plane(env, 'frontwall', hall + 2, H + 1, 0, H / 2, -0.15);
    plane(env, 'curtain', (hall - screen.w) / 2 - 0.2, H, -(screen.w / 2 + (hall - screen.w) / 4 + 0.1), H / 2, -0.1);
    plane(env, 'curtain', (hall - screen.w) / 2 - 0.2, H, (screen.w / 2 + (hall - screen.w) / 4 + 0.1), H / 2, -0.1);
    plane(env, 'exit', 0.7, 0.28, -hall / 2 + 0.9, 2.6, -0.08);

    // Side walls, clipped so they never reach behind the viewer
    const wallClip = (xw) => {
      const lateral = Math.abs(xw - cam.x);
      const budget = xw < cam.x ? -angLo : angHi; // how far towards that wall the view reaches
      const minAhead = budget > 0.05 ? Math.max(0.6, lateral / Math.tan(Math.min(budget, 85 * RAD))) : lateral * 4;
      return Math.max(0.5, backZ - minAhead);
    };
    for (const side of [-1, 1]) {
      const xw = (side * hall) / 2;
      const zEnd = wallClip(xw);
      plane(env, 'wall', zEnd, H, xw, H / 2, zEnd / 2, `rotateY(${side * -90}deg)`);
      for (let z = 3; z < zEnd - 0.5; z += 4.5) plane(env, 'sconce', 1.4, 1.4, xw - side * 0.02, 3.2, z, `rotateY(${side * -90}deg)`);
    }
    // Ceiling and floor at the front
    const ceilAhead = Math.max(0.8, (H - cam.y) / Math.tan(80 * RAD + Math.min(0, camT.pitch)));
    const ceilEnd = Math.max(0.5, backZ - ceilAhead);
    plane(env, 'ceiling', hall, ceilEnd, 0, H, ceilEnd / 2, 'rotateX(90deg)');
    const frontFloorEnd = Math.min(SV.firstRow(layout, s) - s.rowPitch / 2, backZ - 0.8);
    if (frontFloorEnd > 0.2) plane(env, 'floor', hall, frontFloorEnd, 0, 0, frontFloorEnd / 2, 'rotateX(90deg)');

    // Rows in front of the chosen seat: stepped floor, seat backs, and heads where seats are booked
    const rowsG = E.rows; rowsG.textContent = '';
    const seatRow = state.seat.row;
    for (let i = 0; i < seatRow; i++) {
      const row = layout.rows[i];
      const zr = SV.rowDistance(row, s, layout);
      const fl = SV.rowFloor(row, s);
      const ahead = cam.z - zr;
      if (ahead < 0.3) continue;
      const [xa, xb] = xRangeAt(ahead - 0.35);
      const lo = Math.max(xa, -hall / 2), hi = Math.min(xb, hall / 2);
      if (hi <= lo) continue;
      const minY = cam.y - (ahead - 0.35) * Math.tan(maxDepress);

      // tread + riser
      const treadZ0 = zr - s.rowPitch / 2, treadZ1 = Math.min(zr + s.rowPitch / 2, cam.z - 0.4);
      if (fl > minY && treadZ1 > treadZ0) plane(rowsG, 'tread', hi - lo, treadZ1 - treadZ0, (lo + hi) / 2, fl, (treadZ0 + treadZ1) / 2, 'rotateX(90deg)');
      if (s.riserPerRow > 0 && i > 0) {
        const rb = Math.max(fl - s.riserPerRow, minY);
        if (fl > rb) plane(rowsG, 'riser lit', hi - lo, fl - rb, (lo + hi) / 2, (fl + rb) / 2, treadZ0);
      }

      // seat backs grouped into contiguous blocks
      const blocks = [];
      for (const seat of row.seats) {
        const sx = ((seat.cx - layout.centerX) / layout.seatPitchPx) * s.seatWidth;
        const last = blocks[blocks.length - 1];
        if (last && sx - last.x1 < s.seatWidth * 1.6) last.x1 = sx; else blocks.push({ x0: sx, x1: sx });
      }
      const backTop = fl + 0.98, backBot = Math.max(fl + 0.25, minY);
      const zBack = zr + 0.32;
      for (const b of blocks) {
        const a = Math.max(b.x0 - s.seatWidth / 2, lo), c = Math.min(b.x1 + s.seatWidth / 2, hi);
        if (c - a > 0.05 && backTop > backBot) plane(rowsG, 'seatback', c - a, backTop - backBot, (a + c) / 2, (backTop + backBot) / 2, zBack);
      }

      // audience: heads for booked seats (only the nearest rows matter visually)
      if (s.showAudience && seatRow - i <= 8) {
        for (const seat of row.seats) {
          if (seat.status !== 'occupied') continue;
          const sx = ((seat.cx - layout.centerX) / layout.seatPitchPx) * s.seatWidth;
          if (sx < lo || sx > hi) continue;
          plane(rowsG, 'shoulders', 0.46, 0.22, sx, fl + 1.02, zr + 0.12);
          plane(rowsG, 'head', 0.19, 0.25, sx, fl + 1.24, zr + 0.1);
        }
      }
    }

    renderPanel(view);
  }

  // ---------- Side panel ----------
  function seatName(seat) {
    const row = state.layout.rows[seat.row];
    return `Row ${row.label} · Seat ${seat.label || '?'}`;
  }
  function ordinal(n) { const s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }

  function metricRow(label, value, pos, zoneA, zoneB) {
    const el = h('div', 'metric');
    el.innerHTML = `<span>${esc(label)}</span><span class="v">${esc(value)}</span>
      <div class="bar"><i class="zone" style="left:${zoneA}%;width:${zoneB - zoneA}%"></i><i class="mark" style="left:calc(${Math.max(0, Math.min(100, pos))}% - 1px)"></i></div>`;
    return el;
  }

  function renderPanel(view) {
    const E = state.els, m = view.metrics, seat = state.seat;
    const color = m.score >= 85 ? '#49d68c' : m.score >= 70 ? '#a6e05a' : m.score >= 50 ? '#ffc850' : '#ff6b6b';
    const circ = 2 * Math.PI * 31;
    E.arc.setAttribute('stroke', color);
    E.arc.setAttribute('stroke-dasharray', `${(m.score / 100) * circ} ${circ}`);
    E.num.textContent = m.score;
    E.verdict.textContent = m.verdict;
    E.seatline.textContent = `${seatName(seat)} · ${ordinal(seat.row + 1)} row from screen`;
    E.seatpill.innerHTML = `${esc(seatName(seat))}${seat.status === 'occupied' ? ' (booked)' : ''}<small>${m.distance.toFixed(1)} m from screen</small>`;

    E.metrics.textContent = '';
    E.metrics.append(
      metricRow('Screen fills your view', `${Math.round(m.hAngle)}°`, (m.hAngle / 70) * 100, (33 / 70) * 100, (46 / 70) * 100),
      metricRow('Neck angle (to centre)', `${m.vAngle >= 0 ? '↑' : '↓'} ${Math.abs(Math.round(m.vAngle))}°`, ((m.vAngle + 20) / 50) * 100, (10 / 50) * 100, (28 / 50) * 100),
      metricRow('Off-centre angle', `${Math.round(m.offAxis)}°`, (m.offAxis / 40) * 100, 0, (12 / 40) * 100),
      metricRow('Distance ÷ screen width', `${m.widths.toFixed(2)}×`, (m.widths / 2.5) * 100, (1.1 / 2.5) * 100, (1.6 / 2.5) * 100)
    );
    E.notes.innerHTML = [...m.notes, '🔊 ' + m.sound].map((n) => `<li>${esc(n)}</li>`).join('');

    // chips for the user's selected seats
    E.chipwrap.style.display = state.selected.length ? '' : 'none';
    E.chips.textContent = '';
    for (const sel of state.selected) {
      const c = h('span', 'chip' + (sel === seat ? ' on' : ''), esc(`${state.layout.rows[sel.row].label}${sel.label}`));
      c.title = seatName(sel);
      c.onclick = () => setSeat(sel);
      E.chips.appendChild(c);
    }
    renderMap();
  }

  function renderMap() {
    const E = state.els, L = state.layout;
    const map = E.map;
    const width = map.clientWidth || 322;
    const pad = 12, screenBand = 22;
    const spanX = L.maxX - L.minX + L.seatW, spanY = L.maxY - L.minY + L.seatH;
    const k = Math.min((width - pad * 2) / spanX, 9 / Math.max(L.seatW, 1));
    const height = spanY * k + pad * 2 + screenBand;
    map.style.height = height + 'px';
    map.textContent = '';
    const top = L.screenSide === 'bottom' ? pad : pad + screenBand;
    const offX = (width - spanX * k) / 2;
    for (const seat of L.seats) {
      const d = h('div', 's ' + seat.status + (seat === state.seat ? ' current' : ''));
      const w = Math.max(3, L.seatW * k * 0.82);
      d.style.width = d.style.height = w + 'px';
      d.style.left = offX + (seat.cx - L.minX + L.seatW / 2) * k - w / 2 + 'px';
      d.style.top = top + (seat.cy - L.minY + L.seatH / 2) * k - w / 2 + 'px';
      d.title = seatName(seat) + (seat.status === 'occupied' ? ' (booked)' : '');
      d.onclick = () => setSeat(seat);
      map.appendChild(d);
    }
    const bar = h('div', 'scr'), lbl = h('div', 'scrl', 'SCREEN');
    if (L.screenSide === 'bottom') { bar.style.bottom = '14px'; lbl.style.bottom = '2px'; }
    else { bar.style.top = '8px'; lbl.style.top = '12px'; }
    map.append(bar, lbl);
  }

  const SETTING_DEFS = [
    { key: 'screenWidth', label: 'Screen width', min: 0, max: 26, step: 0.5, fmt: (v) => (v > 0 ? v + ' m' : 'Auto') },
    { key: 'firstRowDistance', label: 'First row → screen', min: 0, max: 10, step: 0.1, fmt: (v) => (v > 0 ? v.toFixed(1) + ' m' : 'Auto') },
    { key: 'rowPitch', label: 'Row spacing', min: 0.8, max: 2, step: 0.05, fmt: (v) => v.toFixed(2) + ' m' },
    { key: 'riserPerRow', label: 'Stadium step per row', min: 0, max: 0.5, step: 0.02, fmt: (v) => v.toFixed(2) + ' m' },
    { key: 'screenBottom', label: 'Screen bottom height', min: 0.5, max: 3, step: 0.1, fmt: (v) => v + ' m' },
    { key: 'fov', label: 'Preview field of view', min: 40, max: 90, step: 1, fmt: (v) => v + '°' }
  ];

  function renderSettings() {
    const box = state.els.settings, s = state.settings;
    box.textContent = '';
    const grid = h('div', 'set');
    const aspect = h('select');
    for (const [v, t] of [[2.39, 'Scope 2.39:1 (most multiplexes)'], [1.85, 'Flat 1.85:1'], [1.9, 'IMAX digital 1.90:1'], [1.43, 'IMAX 70mm 1.43:1'], [1.78, '16:9']]) {
      const o = h('option', null, t); o.value = v; if (Math.abs(s.aspect - v) < 0.01) o.selected = true; aspect.appendChild(o);
    }
    aspect.onchange = () => update('aspect', Number(aspect.value));
    grid.append(h('span', null, 'Screen shape'), h('span', 'val', ''), aspect);
    for (const d of SETTING_DEFS) {
      const val = h('span', 'val', d.fmt(s[d.key]));
      const r = h('input'); r.type = 'range'; r.min = d.min; r.max = d.max; r.step = d.step; r.value = s[d.key];
      r.oninput = () => { val.textContent = d.fmt(Number(r.value)); update(d.key, Number(r.value), true); };
      grid.append(h('span', null, d.label), val, r);
    }
    const aud = h('label', null, `<input type="checkbox" ${s.showAudience ? 'checked' : ''}> Show people in booked seats ahead`);
    aud.style.gridColumn = '1 / -1';
    aud.querySelector('input').onchange = (e) => update('showAudience', e.target.checked);
    const reset = h('button', 'btn', 'Reset to defaults'); reset.type = 'button'; reset.style.gridColumn = '1 / -1';
    reset.onclick = () => { state.settings = { ...SV.DEFAULT_SETTINGS, aspect: state.settings.aspect }; save(); renderSettings(); render(); };
    grid.append(aud, reset);
    box.appendChild(grid);
  }

  function update(key, value, instant) { state.settings[key] = value; save(); render(instant); }
  function save() { try { chrome.storage.sync.set({ settings: state.settings }); } catch (_) {} }

  function setSeat(seat) { if (!seat) return; state.seat = seat; render(false); }

  function moveSeat(dirX, dirRow) {
    const L = state.layout, cur = state.seat;
    if (dirX) {
      const row = L.rows[cur.row].seats;
      const i = row.indexOf(cur) + dirX;
      if (row[i]) setSeat(row[i]);
      return;
    }
    const target = L.rows[cur.row + dirRow];
    if (!target) return;
    let best = target.seats[0];
    for (const s of target.seats) if (Math.abs(s.cx - cur.cx) < Math.abs(best.cx - cur.cx)) best = s;
    setSeat(best);
  }

  // ---------- Trailer ----------
  function banner(msg, ms) {
    const b = state.els.banner; b.textContent = msg || '';
    clearTimeout(banner.t);
    if (msg && ms) banner.t = setTimeout(() => { if (b.textContent === msg) b.textContent = ''; }, ms);
  }

  function showPlaceholder(kind) {
    const scr = state.els.screen;
    scr.textContent = '';
    if (kind === 'grid') { scr.appendChild(h('div', 'grid')); return; }
    const ph = h('div', 'placeholder');
    const q = encodeURIComponent((state.title || 'movie') + ' trailer');
    ph.innerHTML = `<h2>${esc(state.title || 'Your movie')}</h2><p>${esc(kind || 'No trailer found')}</p>
      <a href="https://www.youtube.com/results?search_query=${q}" target="_blank" rel="noopener">Search YouTube ↗</a>`;
    scr.appendChild(ph);
  }

  function populateSelect() {
    const sel = state.els.select;
    sel.textContent = '';
    state.trailers.forEach((t, i) => {
      const o = h('option', null, esc(`${i + 1}. ${t.title || t.videoId}${t.length ? ' (' + t.length + ')' : ''}`));
      o.value = i; sel.appendChild(o);
    });
    const g = h('option', null, '▦ Calibration grid (check distortion)'); g.value = -1; sel.appendChild(g);
  }

  async function loadTrailers(title) {
    title = (title || '').trim();
    state.title = title;
    state.els.title.value = title;
    state.els.moviepill.textContent = title ? `🎬 ${title}` : '🎬 Movie';
    if (!title) { state.trailers = []; populateSelect(); showPlaceholder('Type the movie title to load its trailer'); return; }
    banner('Finding the trailer on YouTube…');
    showPlaceholder('Loading trailer…');
    let res;
    try { res = await chrome.runtime.sendMessage({ type: 'seatview:searchTrailers', query: title }); }
    catch (e) { res = { ok: false, error: String(e) }; }
    if (!state.host) return;
    if (!res || !res.ok || !res.results.length) {
      state.trailers = []; populateSelect();
      banner(res && res.error ? 'Could not reach YouTube: ' + res.error : 'No trailer found – try editing the title.', 6000);
      showPlaceholder('No trailer found');
      return;
    }
    banner('');
    state.trailers = res.results;
    populateSelect();
    playTrailer(0);
  }

  function playTrailer(i) {
    const E = state.els;
    if (i === -1) { E.select.value = -1; showPlaceholder('grid'); E.yt.removeAttribute('href'); return; }
    if (!state.trailers.length) return;
    if (i >= state.trailers.length) { banner('No more results – edit the title and search again.', 5000); return; }
    state.trailerIdx = i;
    E.select.value = i;
    const t = state.trailers[i];
    E.yt.href = 'https://www.youtube.com/watch?v=' + t.videoId;
    const params = new URLSearchParams({
      autoplay: '1', mute: state.muted ? '1' : '0', controls: '0', rel: '0', playsinline: '1', modestbranding: '1',
      loop: '1', playlist: t.videoId, enablejsapi: '1', iv_load_policy: '3', disablekb: '1'
    });
    if (/^https?:/.test(location.origin)) params.set('origin', location.origin);
    const f = document.createElement('iframe');
    f.src = `https://www.youtube-nocookie.com/embed/${t.videoId}?${params}`;
    f.allow = 'autoplay; encrypted-media; picture-in-picture';
    f.referrerPolicy = 'strict-origin-when-cross-origin';
    f.title = t.title || 'Trailer';
    f.addEventListener('load', () => {
      ytPost({ event: 'listening', id: 'seatview', channel: 'widget' });
      if (!state.muted) ytCommand('unMute');
    });
    E.screen.textContent = '';
    E.screen.appendChild(f);
    state.iframe = f;
    state.playing = true;
    syncButtons();
  }

  function ytPost(obj) { try { state.iframe && state.iframe.contentWindow.postMessage(JSON.stringify(obj), '*'); } catch (_) {} }
  function ytCommand(func, args = []) { ytPost({ event: 'command', func, args }); }

  function onYtMessage(e) {
    if (!state.iframe || e.source !== state.iframe.contentWindow) return;
    let d = e.data;
    try { if (typeof d === 'string') d = JSON.parse(d); } catch (_) { return; }
    if (!d) return;
    if (d.event === 'onError') {
      banner(`That video can't be embedded – trying the next one…`, 3500);
      setTimeout(() => playTrailer(state.trailerIdx + 1), 600);
    }
    if (d.event === 'onStateChange' || (d.event === 'infoDelivery' && d.info && 'playerState' in d.info)) {
      const ps = d.event === 'onStateChange' ? d.info : d.info.playerState;
      if (ps === 1) { state.playing = true; syncButtons(); }
      if (ps === 2) { state.playing = false; syncButtons(); }
    }
  }

  function togglePlay() { state.playing = !state.playing; ytCommand(state.playing ? 'playVideo' : 'pauseVideo'); syncButtons(); }
  function toggleMute() {
    state.muted = !state.muted;
    if (state.muted) ytCommand('mute'); else { ytCommand('unMute'); ytCommand('setVolume', [80]); }
    syncButtons();
  }
  function syncButtons() {
    state.els.play.textContent = state.playing ? '❚❚ Pause' : '▶ Play';
    state.els.mute.textContent = state.muted ? '🔇 Unmute' : '🔊 Mute';
  }

  function onKey(e) {
    if (!state.host) return;
    const inInput = e.composedPath().some((n) => n && (n.tagName === 'INPUT' || n.tagName === 'SELECT'));
    if (e.key === 'Escape') { e.preventDefault(); SV.Overlay.close(); return; }
    if (inInput) return;
    const up = state.layout.screenSide === 'bottom' ? 1 : -1;
    const map = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, up], ArrowDown: [0, -up] };
    if (map[e.key]) { e.preventDefault(); e.stopPropagation(); moveSeat(...map[e.key]); }
    else if (e.key === ' ') { e.preventDefault(); e.stopPropagation(); togglePlay(); }
    else if (e.key === 'm' || e.key === 'M') { e.preventDefault(); toggleMute(); }
  }

  SV.Overlay = {
    isOpen: () => !!state.host,
    /**
     * ctx: { layout, selected: Seat[], seat: Seat, title, settings, message }
     */
    open(ctx) {
      if (state.host) this.close();
      Object.assign(state, {
        layout: ctx.layout, selected: ctx.selected || [], seat: ctx.seat, settings: { ...SV.DEFAULT_SETTINGS, ...(ctx.settings || {}) },
        trailers: [], trailerIdx: 0, muted: true, playing: true, iframe: null
      });
      document.documentElement.appendChild(build());
      window.addEventListener('message', onYtMessage);
      window.addEventListener('keydown', onKey, true);
      renderSettings();
      requestAnimationFrame(() => render(true));
      if (ctx.message) banner(ctx.message, 7000);
      loadTrailers(ctx.title || '');
      syncButtons();
    },
    close() {
      if (!state.host) return;
      window.removeEventListener('message', onYtMessage);
      window.removeEventListener('keydown', onKey, true);
      state.host.remove();
      state.host = null; state.iframe = null;
    }
  };
})();
