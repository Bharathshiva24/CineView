const key = document.getElementById('key');
chrome.storage.sync.get({ apiKey: '' }).then(({ apiKey }) => { key.value = apiKey; });
document.getElementById('save').onclick = async () => {
  await chrome.storage.sync.set({ apiKey: key.value.trim() });
  document.getElementById('saved').textContent = 'Saved ✓';
};
document.getElementById('reset').onclick = async () => {
  await chrome.storage.sync.remove('settings');
  const all = await chrome.storage.local.get(null);
  await chrome.storage.local.remove(Object.keys(all).filter((k) => k.startsWith('yt:')));
  document.getElementById('saved').textContent = 'Reset ✓';
};
