# SeatView – see the screen from your seat

A Chrome extension (Manifest V3) for **District** and **BookMyShow**. After you pick your seats, click the extension. It opens a 3D view of the hall from that seat, with the movie's trailer playing on the screen.

## Install (developer mode)
1. Unzip this folder.
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and choose the `seatview` folder.
4. Pin the SeatView icon to the toolbar.

## Use
1. Open a seat selection page on District or BookMyShow and select your seats.
2. Click the SeatView icon, or press **Alt+Shift+S**.
3. In the preview:
   - Click any seat on the mini map to compare it. You can also use the arrow keys.
   - Your selected seats appear as chips you can switch between.
   - **Space** plays or pauses, **M** mutes or unmutes, **Esc** closes.
   - If the wrong trailer loads, edit the movie title and press **Find trailer**, or use **Next ›**.
   - **Calibration grid** shows a test pattern so you can see the keystone (off-centre) distortion clearly.
   - **Theatre settings** let you set the screen width, first-row distance, row spacing, stadium step and screen shape. These are remembered.

To try it without a booking site, open the popup on any page and click **Try the demo theatre**.

## How it works
| Part | File | What it does |
|---|---|---|
| Seat map reader | `content/detector.js` | Finds the seat grid using the most common small, square, numbered element on the page. It doesn't rely on site class names, so it should keep working when the sites change their CSS. It groups seats into rows by vertical position and finds the screen side from text like "SCREEN THIS WAY". It works out seat status from ARIA attributes and class names, then from fill colour (selected seats are strongly coloured, booked seats show an ✕ icon), then from the seats you clicked. |
| Theatre model | `content/geometry.js` | Turns a seat into a position in metres (x = left/right, y = eye height on a stepped floor, z = distance from the screen). It also calculates the viewing metrics: the horizontal angle the screen fills (THX recommends about 36–40°), neck angle, off-centre angle, distance divided by screen width, a 0–100 score and a sound sweet-spot note. |
| 3D preview | `content/overlay.js` | A CSS-3D scene inside a shadow root: the screen, curtains, walls, ceiling, stepped rows, seat backs, and heads in already-booked seats in front of you. The camera sits at your eye position and turns towards the centre of the screen. The trailer is a real YouTube embed placed on the screen surface, so the perspective you see is the true perspective. |
| Trailer search | `background.js` | Searches YouTube for "<title> official trailer". It reads YouTube's public search page, so no API key is needed. Results are ranked to prefer official trailers and teasers and to push down reactions, reviews and other junk. Results are cached for 3 days. If a video can't be embedded, the preview moves on to the next one automatically. You can add a YouTube Data API v3 key in **Options**, which is then tried first. |
| Title detection | `content/main.js` | Uses the largest heading in the booking page header, falling back to `og:title` and then the page title. It cleans off tags like "(UA)", "2D" and "IMAX", and adds the language if the page shows one. It also remembers the title from the movie's own details page. |

## Limits
- **Dimensions are estimates.** Seat maps don't give real measurements. Screen width is set from the hall width the seat map implies, and the first row is placed about 0.6 × screen width from the screen (a common design guideline). If you know the hall, adjust **Theatre settings** (for example, recliners → row spacing 1.6 m; IMAX → shape 1.90:1 and a wider screen).
- If a site draws its seat map on a `<canvas>`, the reader can't see the seats. SeatView then shows a typical hall, and you click the seat on the mini map that matches yours.
- YouTube's search page layout can change. If trailers stop loading, add a free YouTube Data API key in Options.
- Autoplay only works while muted (a browser rule). Press **Unmute**.
- The bundled demo page runs from an extension URL. YouTube sometimes refuses to play embeds there, but they play normally on District and BookMyShow.

## Files
```
manifest.json        MV3 manifest (content scripts on district.in and bookmyshow.com)
background.js        trailer search + keyboard shortcut
content/*.js         detector, geometry, overlay, entry point
popup/               toolbar popup (opens the preview, injects the scripts into tabs that were already open)
options/             optional YouTube API key, reset
demo/                District-style mock seat map for testing
icons/
```
